from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User
from app.schemas import UserRegister, UserLogin, UserResponse, TokenResponse
from app.security import (
    hash_password,
    verify_password,
    create_access_token,
    get_current_user,
    record_audit
)

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_user(req: UserRegister, request: Request, db: Session = Depends(get_db)):
    """
    Registers a new user account with specified role (admin, owner, viewer).
    """
    existing = db.query(User).filter(User.email == req.email.lower()).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="A user with this email address already exists."
        )

    user = User(
        email=req.email.lower(),
        hashed_password=hash_password(req.password),
        full_name=req.full_name,
        role=req.role,
        token_version=1,
        is_active=True
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    record_audit(
        db=db,
        action="USER_REGISTER",
        target_type="USER",
        target_id=str(user.id),
        status="SUCCESS",
        user=user,
        details={"role": user.role, "email": user.email},
        request=request
    )

    return user


@router.post("/login", response_model=TokenResponse)
def login(req: UserLogin, request: Request, db: Session = Depends(get_db)):
    """
    Authenticates user credentials and returns JWT bearer token.
    Records both successful logins and refused/failed attempts in the audit trail.
    """
    email_clean = req.email.lower()
    user = db.query(User).filter(User.email == email_clean).first()

    if not user or not verify_password(req.password, user.hashed_password):
        record_audit(
            db=db,
            action="LOGIN_FAILED",
            target_type="AUTH",
            target_id=email_clean,
            status="REFUSED",
            user_email=email_clean,
            reason="Invalid credentials supplied",
            request=request
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password."
        )

    if not user.is_active:
        record_audit(
            db=db,
            action="LOGIN_FAILED",
            target_type="AUTH",
            target_id=email_clean,
            status="REFUSED",
            user=user,
            reason="Account is deactivated",
            request=request
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Your account has been deactivated."
        )

    access_token = create_access_token(
        data={"sub": str(user.id), "role": user.role, "token_version": user.token_version}
    )

    record_audit(
        db=db,
        action="LOGIN_SUCCESS",
        target_type="AUTH",
        target_id=str(user.id),
        status="SUCCESS",
        user=user,
        request=request
    )

    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(user)
    )


@router.get("/me", response_model=UserResponse)
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    """
    Returns the authenticated user's profile.
    """
    return current_user


@router.post("/logout")
def logout(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Logs out the user and increments token_version in database.
    This guarantees IMMEDIATE server-side invalidation of all existing tokens across all devices.
    """
    current_user.token_version += 1
    db.commit()

    record_audit(
        db=db,
        action="LOGOUT",
        target_type="AUTH",
        target_id=str(current_user.id),
        status="SUCCESS",
        user=current_user,
        details={"new_token_version": current_user.token_version},
        request=request
    )

    return {"message": "Successfully logged out. All active session tokens have been invalidated."}
