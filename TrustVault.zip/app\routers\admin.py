from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.crypto import verify_audit_chain
from app.database import get_db
from app.models import User, Document, DocumentPermission, AuditLog, SecurityAlert
from app.schemas import UserResponse, SecurityAlertResponse
from app.security import require_role, record_audit

router = APIRouter(prefix="/api/admin", tags=["Administration"])


@router.get("/overview")
def get_admin_overview(
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db)
):
    """
    Returns administrative security overview and telemetry.
    """
    total_users = db.query(func.count(User.id)).scalar() or 0
    total_documents = db.query(func.count(Document.id)).filter(Document.is_deleted == False).scalar() or 0
    total_logs = db.query(func.count(AuditLog.id)).scalar() or 0
    refused_attempts = db.query(func.count(AuditLog.id)).filter(AuditLog.status == "REFUSED").scalar() or 0
    active_alerts = db.query(func.count(SecurityAlert.id)).filter(SecurityAlert.is_resolved == False).scalar() or 0

    # Cryptographic integrity check
    all_logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    is_valid, msg, failed_id = verify_audit_chain(all_logs)

    # Top recent refused events
    recent_refusals = db.query(AuditLog).filter(
        AuditLog.status == "REFUSED"
    ).order_by(AuditLog.id.desc()).limit(10).all()

    return {
        "metrics": {
            "total_users": total_users,
            "total_active_documents": total_documents,
            "total_audit_records": total_logs,
            "refused_access_attempts": refused_attempts,
            "unresolved_security_alerts": active_alerts
        },
        "audit_integrity": {
            "chain_valid": is_valid,
            "message": msg,
            "verified_records": len(all_logs) if is_valid else (failed_id - 1 if failed_id else 0),
            "tampered_record_id": failed_id
        },
        "recent_refusals": [
            {
                "id": r.id,
                "timestamp": r.timestamp,
                "user_email": r.user_email,
                "action": r.action,
                "target_id": r.target_id,
                "reason": r.reason,
                "ip": r.ip_address
            }
            for r in recent_refusals
        ]
    }


@router.get("/users", response_model=List[UserResponse])
def list_all_users(
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db)
):
    """
    Lists all user accounts in the organization.
    """
    return db.query(User).order_by(User.created_at.desc()).all()


@router.put("/users/{user_id}/status")
def toggle_user_status(
    user_id: int,
    is_active: bool,
    request: Request,
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db)
):
    """
    Activates or deactivates a user.
    If deactivating, immediately increments token_version to terminate all active sessions.
    """
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found.")

    if target.id == current_user.id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot deactivate your own account.")

    target.is_active = is_active
    target.token_version += 1  # Invalidate any live JWT token immediately
    db.commit()

    record_audit(
        db=db,
        action="USER_STATUS_CHANGE",
        target_type="USER",
        target_id=str(user_id),
        status="SUCCESS",
        user=current_user,
        details={"user_email": target.email, "is_active": is_active, "revocation": "token_version_bumped"},
        request=request
    )

    return {"message": f"User {target.email} is now {'active' if is_active else 'deactivated'}."}


@router.get("/alerts", response_model=List[SecurityAlertResponse])
def list_security_alerts(
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db)
):
    """
    Lists all triggered security alerts.
    """
    return db.query(SecurityAlert).order_by(SecurityAlert.id.desc()).all()


@router.post("/alerts/{alert_id}/resolve")
def resolve_security_alert(
    alert_id: int,
    request: Request,
    current_user: User = Depends(require_role("admin")),
    db: Session = Depends(get_db)
):
    """
    Marks a security alert as resolved.
    """
    alert = db.query(SecurityAlert).filter(SecurityAlert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found.")

    alert.is_resolved = True
    db.commit()

    record_audit(
        db=db,
        action="ALERT_RESOLVED",
        target_type="SYSTEM",
        target_id=str(alert_id),
        status="SUCCESS",
        user=current_user,
        details={"alert_type": alert.alert_type},
        request=request
    )

    return {"message": f"Alert {alert_id} marked as resolved."}
