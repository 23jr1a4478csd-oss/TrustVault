import io
import pytest
from tests.conftest import auth_header_for
from app.models import AuditLog, DocumentPermission


SAMPLE_PDF = b"%PDF-1.4 sample content for automated security tests"


def upload_test_doc(client, owner, title="Confidential Roadmap", filename="roadmap.pdf"):
    headers = auth_header_for(owner)
    file_tuple = ("file", (filename, io.BytesIO(SAMPLE_PDF), "application/pdf"))
    res = client.post(
        "/api/documents/upload",
        headers=headers,
        data={"title": title, "category": "Engineering"},
        files=[file_tuple]
    )
    assert res.status_code == 201
    return res.json()


def test_unauthorized_user_cannot_read_or_download(client, users, db):
    """
    SECURITY PROOF 1:
    Owner 1 uploads a file.
    Viewer 1 (not granted access) attempts to view metadata and download.
    Server MUST reject with 403 Forbidden and record refused attempts in audit log.
    """
    owner = users["owner1"]
    viewer = users["viewer1"]
    doc = upload_test_doc(client, owner, "Q4 Financials", "financials.pdf")
    doc_id = doc["id"]

    # 1. Viewer attempts to fetch metadata
    res_meta = client.get(f"/api/documents/{doc_id}", headers=auth_header_for(viewer))
    assert res_meta.status_code == 403
    assert "Access denied" in res_meta.json()["detail"]

    # 2. Viewer attempts direct download
    res_down = client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(viewer))
    assert res_down.status_code == 403
    assert "Access denied" in res_down.json()["detail"]

    # 3. Check Audit Trail records the refused attempt
    refusal_log = db.query(AuditLog).filter(
        AuditLog.action == "ACCESS_READ",
        AuditLog.target_id == doc_id,
        AuditLog.status == "REFUSED",
        AuditLog.user_email == viewer.email
    ).first()
    assert refusal_log is not None
    assert "No access permission granted" in refusal_log.reason


def test_other_owner_cannot_access_unshared_doc(client, users):
    """
    SECURITY PROOF 2:
    Horizontal privilege escalation: Owner 2 cannot access Owner 1's document.
    """
    owner1 = users["owner1"]
    owner2 = users["owner2"]
    doc = upload_test_doc(client, owner1, "Secret R&D", "rnd.pdf")
    doc_id = doc["id"]

    res = client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(owner2))
    assert res.status_code == 403


def test_instant_revocation(client, users, db):
    """
    SECURITY PROOF 3 (NON-NEGOTIABLE #3):
    1. Owner 1 grants READ permission to Viewer 1.
    2. Viewer 1 can download successfully.
    3. Owner 1 revokes Viewer 1's permission.
    4. Viewer 1's very next download attempt is IMMEDIATELY rejected (403 Forbidden).
    """
    owner = users["owner1"]
    viewer = users["viewer1"]
    doc = upload_test_doc(client, owner, "Client Contract", "contract.pdf")
    doc_id = doc["id"]

    # Step 1: Grant READ permission
    grant_res = client.post(
        f"/api/documents/{doc_id}/permissions",
        headers=auth_header_for(owner),
        json={"user_email": viewer.email, "permission_level": "READ"}
    )
    assert grant_res.status_code == 201

    # Step 2: Viewer downloads successfully
    down1 = client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(viewer))
    assert down1.status_code == 200
    assert down1.content == SAMPLE_PDF

    # Step 3: Owner revokes permission immediately
    revoke_res = client.delete(
        f"/api/documents/{doc_id}/permissions/{viewer.id}",
        headers=auth_header_for(owner)
    )
    assert revoke_res.status_code == 200
    assert "immediately" in revoke_res.json()["message"]

    # Step 4: Viewer attempts download again - MUST FAIL SYNCHRONOUSLY
    down2 = client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(viewer))
    assert down2.status_code == 403
    assert "Access denied" in down2.json()["detail"]


def test_read_permission_cannot_edit_or_delete(client, users):
    """
    SECURITY PROOF 4:
    Viewer with READ permission cannot perform EDIT or DELETE operations.
    """
    owner = users["owner1"]
    viewer = users["viewer1"]
    doc = upload_test_doc(client, owner, "Budget", "budget.pdf")
    doc_id = doc["id"]

    # Grant READ only
    client.post(
        f"/api/documents/{doc_id}/permissions",
        headers=auth_header_for(owner),
        json={"user_email": viewer.email, "permission_level": "READ"}
    )

    # Attempt PUT (edit)
    res_edit = client.put(
        f"/api/documents/{doc_id}",
        headers=auth_header_for(viewer),
        data={"title": "Hacked Title"}
    )
    assert res_edit.status_code == 403
    assert "EDIT permission" in res_edit.json()["detail"]

    # Attempt DELETE
    res_del = client.delete(
        f"/api/documents/{doc_id}",
        headers=auth_header_for(viewer)
    )
    assert res_del.status_code == 403
    assert "Only the document owner" in res_del.json()["detail"]


def test_non_owner_cannot_grant_permissions(client, users):
    """
    SECURITY PROOF 5:
    Viewer cannot grant permissions to other users.
    """
    owner = users["owner1"]
    viewer1 = users["viewer1"]
    viewer2 = users["viewer2"]
    doc = upload_test_doc(client, owner, "M&A Strategy", "ma.pdf")
    doc_id = doc["id"]

    # Viewer 1 attempts to grant access to Viewer 2
    res = client.post(
        f"/api/documents/{doc_id}/permissions",
        headers=auth_header_for(viewer1),
        json={"user_email": viewer2.email, "permission_level": "READ"}
    )
    assert res.status_code == 403
    assert "Only the document owner" in res.json()["detail"]


def test_zero_trust_document_listing_isolation(client, users):
    """
    SECURITY PROOF 6:
    Documents not shared with a user NEVER appear in their document listing or search results.
    """
    owner1 = users["owner1"]
    viewer = users["viewer1"]

    # Owner 1 uploads doc
    doc = upload_test_doc(client, owner1, "Secret Strategy", "secret.pdf")

    # Viewer lists documents
    res = client.get("/api/documents", headers=auth_header_for(viewer))
    assert res.status_code == 200
    listed_ids = [d["id"] for d in res.json()]
    assert doc["id"] not in listed_ids
