import hashlib
import hmac
import json
import os
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple
import jwt
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

from app.config import SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES
from app.crypto import compute_audit_hash, GENESIS_HASH
from app.database import get_db
from app.models import User, Document, DocumentPermission, AuditLog, SecurityAlert, utcnow_str

security_scheme = HTTPBearer(auto_error=False)


# ==========================================
# PASSWORD HASHING (PBKDF2-HMAC-SHA256)
# ==========================================
def hash_password(password: str) -> str:
    """
    Hashes password using PBKDF2-HMAC-SHA256 with 600,000 iterations (OWASP standard).
    Format: pbkdf2:sha256:600000$salt_hex$hash_hex
    """
    salt = os.urandom(16)
    iterations = 600000
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2:sha256:{iterations}${salt.hex()}${derived.hex()}"


def verify_password(plain_password: str, stored_hash: str) -> bool:
    """
    Verifies a plain password against the stored PBKDF2 hash using constant-time comparison.
    """
    try:
        parts = stored_hash.split("$")
        if len(parts) != 3:
            return False
        header, salt_hex, hash_hex = parts
        _, _, iterations_str = header.split(":")
        iterations = int(iterations_str)
        salt = bytes.fromhex(salt_hex)
        expected_hash = bytes.fromhex(hash_hex)

        calculated = hashlib.pbkdf2_hmac("sha256", plain_password.encode("utf-8"), salt, iterations)
        return hmac.compare_digest(calculated, expected_hash)
    except Exception:
        return False


# ==========================================
# JWT TOKEN HANDLING
# ==========================================
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    now = datetime.now(timezone.utc)
    if expires_delta:
        expire = now + expires_delta
    else:
        expire = now + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire, "iat": now})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session token has expired. Please authenticate again.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication token.",
            headers={"WWW-Authenticate": "Bearer"},
        )


# ==========================================
# AUTHENTICATION DEPENDENCY WITH TOKEN VERSIONING
# ==========================================
def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security_scheme),
    db: Session = Depends(get_db)
) -> User:
    """
    Authenticates bearer token AND verifies user active status and token_version
    against database. This guarantees INSTANT token revocation upon logout or password reset.
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication credentials.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decode_access_token(credentials.credentials)
    user_id_str = payload.get("sub")
    token_version = payload.get("token_version")

    if not user_id_str:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token payload missing subject identifier.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = db.query(User).filter(User.id == int(user_id_str)).first()
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account is deactivated or not found.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # Real-time token version invalidation check
    if token_version is None or user.token_version != token_version:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session has been revoked or invalidated. Please log in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return user


def require_role(*allowed_roles: str):
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied: Action requires one of roles: {', '.join(allowed_roles)} (You have '{current_user.role}')",
            )
        return current_user
    return role_checker


# ==========================================
# CRYPTOGRAPHIC AUDIT LOGGING HELPER
# ==========================================
def record_audit(
    db: Session,
    action: str,
    target_type: str,
    target_id: Optional[str],
    status: str,
    user: Optional[User] = None,
    user_email: Optional[str] = None,
    reason: Optional[str] = None,
    details: Optional[dict] = None,
    request: Optional[Request] = None,
) -> AuditLog:
    """
    Appends a new cryptographically chained audit log entry.
    Locks the chain tip and ensures prev_hash chaining is atomic.
    """
    ip_address = None
    user_agent = None
    if request:
        ip_address = request.client.host if request.client else "unknown"
        user_agent = request.headers.get("user-agent", "unknown")[:250]

    email = user.email if user else (user_email or "anonymous")
    user_id = user.id if user else None
    details_str = json.dumps(details or {}, sort_keys=True)
    timestamp = utcnow_str()

    # Query latest record for previous hash
    last_log = db.query(AuditLog).order_by(AuditLog.id.desc()).first()
    prev_hash = last_log.record_hash if last_log else GENESIS_HASH

    # Create new entry
    new_log = AuditLog(
        timestamp=timestamp,
        user_id=user_id,
        user_email=email,
        action=action,
        target_type=target_type,
        target_id=str(target_id) if target_id else None,
        status=status,
        reason=reason,
        ip_address=ip_address,
        user_agent=user_agent,
        details=details_str,
        prev_hash=prev_hash,
        record_hash="PENDING"
    )
    db.add(new_log)
    db.flush()  # Assigns new_log.id

    # Compute cryptographic signature over canonical entry
    new_log.record_hash = compute_audit_hash(
        log_id=new_log.id,
        timestamp=timestamp,
        user_id=user_id,
        user_email=email,
        action=action,
        target_type=target_type,
        target_id=str(target_id) if target_id else None,
        status=status,
        reason=reason,
        ip_address=ip_address,
        details=details_str,
        prev_hash=prev_hash
    )
    db.commit()

    # If action was REFUSED or FAILED, evaluate if a SecurityAlert should be raised
    if status in ("REFUSED", "FAILED"):
        # Check recent refusals in last 10 minutes from this IP/user
        recent_refused = db.query(AuditLog).filter(
            AuditLog.status == "REFUSED",
            AuditLog.user_email == email
        ).order_by(AuditLog.id.desc()).limit(5).all()

        if len(recent_refused) >= 3:
            alert = SecurityAlert(
                severity="WARNING" if len(recent_refused) < 5 else "CRITICAL",
                alert_type="REPEATED_UNAUTHORIZED_ACCESS_ATTEMPTS",
                source_ip=ip_address,
                user_email=email,
                description=f"User {email} triggered {len(recent_refused)} access refusals on target {target_id}. Reason: {reason}",
                is_resolved=False
            )
            db.add(alert)
            db.commit()

    return new_log


# ==========================================
# ZERO-TRUST ACCESS CONTROL EVALUATOR
# ==========================================
def verify_document_access(
    document_id: str,
    user: User,
    required_level: str,  # "READ", "EDIT", or "OWNER"
    db: Session,
    request: Optional[Request] = None
) -> Tuple[Document, Optional[str]]:
    """
    The Single Point of Truth for document access decisions.
    - Owner always has full access.
    - Admin has platform oversight but cannot read confidential content unless granted (Zero-Trust separation of duties).
    - Other users must have an active, non-revoked DocumentPermission record.
    - Logs every decision, including REFUSED attempts.
    """
    doc = db.query(Document).filter(Document.id == document_id, Document.is_deleted == False).first()
    if not doc:
        # Record refusal on non-existent or deleted doc
        record_audit(
            db=db,
            action=f"ACCESS_{required_level}",
            target_type="DOCUMENT",
            target_id=document_id,
            status="REFUSED",
            user=user,
            reason="Document not found or soft-deleted",
            request=request
        )
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found.")

    # 1. Owner check
    if doc.owner_id == user.id:
        return doc, "OWNER"

    # 2. Owner-only operations (delete, manage permissions)
    if required_level == "OWNER":
        record_audit(
            db=db,
            action=f"ACCESS_OWNER_REQUIRED",
            target_type="DOCUMENT",
            target_id=document_id,
            status="REFUSED",
            user=user,
            reason="Action strictly requires document ownership",
            request=request
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: Only the document owner can perform this operation."
        )

    # 3. Check explicit DocumentPermission in database (real-time query, no caching)
    permission = db.query(DocumentPermission).filter(
        DocumentPermission.document_id == document_id,
        DocumentPermission.user_id == user.id
    ).first()

    if not permission:
        # Zero-trust refusal: user has no grant
        record_audit(
            db=db,
            action=f"ACCESS_{required_level}",
            target_type="DOCUMENT",
            target_id=document_id,
            status="REFUSED",
            user=user,
            reason=f"No access permission granted to user {user.email}",
            request=request
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: You have not been granted access to this document."
        )

    # 4. Check permission level sufficiency
    if required_level == "EDIT" and permission.permission_level != "EDIT":
        record_audit(
            db=db,
            action="ACCESS_EDIT",
            target_type="DOCUMENT",
            target_id=document_id,
            status="REFUSED",
            user=user,
            reason=f"Insufficient permission: requested EDIT but user only has READ grant",
            request=request
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied: This operation requires EDIT permission (You only have READ)."
        )

    return doc, permission.permission_level
