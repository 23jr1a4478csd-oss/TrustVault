import os
import uuid
from app.config import UPLOAD_DIR
from app.crypto import encrypt_data
from app.database import SessionLocal
from app.models import User, Document, DocumentPermission, AuditLog, SecurityAlert
from app.security import hash_password, record_audit

# Minimal valid PDF payload
MINIMAL_PDF_BYTES = (
    b"%PDF-1.4\n"
    b"1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
    b"2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\n"
    b"3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R/Resources<<>>>>endobj\n"
    b"xref\n0 4\n0000000000 65535 f \n0000000010 00000 n \n0000000060 00000 n \n0000000115 00000 n \n"
    b"trailer<</Size 4/Root 1 0 R>>\nstartxref\n190\n%%EOF"
)

# Minimal valid DOCX/ZIP payload
MINIMAL_DOCX_BYTES = (
    b"PK\x03\x04\x14\x00\x00\x00\x08\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00\x00"
    b"[Content_Types].xml<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
    b"<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"></Types>"
    b"PK\x01\x02\x14\x00\x14\x00\x00\x00\x08\x00\x00\x00!\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x13\x00\x00\x00"
    b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00[Content_Types].xml"
    b"PK\x05\x06\x00\x00\x00\x00\x01\x00\x01\x00A\x00\x00\x00y\x00\x00\x00\x00\x00"
)

SAMPLE_AUDIT_TEXT = (
    b"TRUSTVAULT COMPLIANCE REPORT\n"
    b"Document Ref: ISO27001-A.9.4.1\n"
    b"Information Access Restriction:\n"
    b"Access to information and application system functions shall be restricted\n"
    b"in accordance with the access control policy.\n"
    b"Status: VERIFIED AND COMPLIANT\n"
)


def seed_database_if_empty():
    db = SessionLocal()
    try:
        # Check if users already exist
        if db.query(User).count() > 0:
            return

        print("[Seed] Populating TrustVault with default users, documents, and verified audit chain...")

        # 1. Create Default Users (3 Required Roles + extras for boundary testing)
        admin = User(
            email="admin@trustvault.internal",
            hashed_password=hash_password("AdminPassword123!"),
            full_name="Elena Rostova (CSO)",
            role="admin",
            token_version=1,
            is_active=True
        )
        owner_marcus = User(
            email="owner@trustvault.internal",
            hashed_password=hash_password("OwnerPassword123!"),
            full_name="Marcus Chen (VP Financial Controller)",
            role="owner",
            token_version=1,
            is_active=True
        )
        viewer_sophia = User(
            email="viewer@trustvault.internal",
            hashed_password=hash_password("ViewerPassword123!"),
            full_name="Sophia Patel (External Auditor)",
            role="viewer",
            token_version=1,
            is_active=True
        )
        owner_carol = User(
            email="carol@trustvault.internal",
            hashed_password=hash_password("CarolPassword123!"),
            full_name="Carol Danvers (R&D Director)",
            role="owner",
            token_version=1,
            is_active=True
        )
        viewer_david = User(
            email="david@trustvault.internal",
            hashed_password=hash_password("DavidPassword123!"),
            full_name="David Kim (Third-Party Contractor)",
            role="viewer",
            token_version=1,
            is_active=True
        )

        db.add_all([admin, owner_marcus, viewer_sophia, owner_carol, viewer_david])
        db.commit()

        # Seed audit logs for registrations
        record_audit(db, "SYSTEM_INIT", "SYSTEM", "genesis", "SUCCESS", details={"version": "1.0.0"})
        for u in [admin, owner_marcus, viewer_sophia, owner_carol, viewer_david]:
            record_audit(db, "USER_REGISTER", "USER", str(u.id), "SUCCESS", user=u, details={"role": u.role})

        # 2. Upload Seed Documents
        def store_and_create_doc(title, orig_filename, category, mime_type, raw_bytes, owner):
            ciphertext, nonce_hex = encrypt_data(raw_bytes)
            stored_name = f"{uuid.uuid4().hex}.enc"
            storage_path = UPLOAD_DIR / stored_name
            with open(storage_path, "wb") as f:
                f.write(ciphertext)

            doc = Document(
                title=title,
                original_filename=orig_filename,
                stored_filename=stored_name,
                category=category,
                mime_type=mime_type,
                file_size=len(raw_bytes),
                owner_id=owner.id,
                encryption_nonce=nonce_hex,
                is_deleted=False
            )
            db.add(doc)
            db.commit()
            db.refresh(doc)

            record_audit(
                db=db,
                action="UPLOAD",
                target_type="DOCUMENT",
                target_id=doc.id,
                status="SUCCESS",
                user=owner,
                details={"title": title, "filename": orig_filename, "size": len(raw_bytes)}
            )
            return doc

        # Doc 1: Confidential Salaries (Marcus owns, NO ONE else has access)
        doc_salaries = store_and_create_doc(
            title="Q3 Executive Salaries and Compensation",
            orig_filename="Q3_Executive_Salaries.pdf",
            category="Salaries",
            mime_type="application/pdf",
            raw_bytes=MINIMAL_PDF_BYTES,
            owner=owner_marcus
        )

        # Doc 2: Customer Contract (Marcus owns, Sophia granted READ)
        doc_contract = store_and_create_doc(
            title="Master Services Agreement - Global Corp",
            orig_filename="Master_Services_Agreement_V4.docx",
            category="Contracts",
            mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            raw_bytes=MINIMAL_DOCX_BYTES,
            owner=owner_marcus
        )

        # Doc 3: ISO Audit Report (Carol owns, Sophia granted EDIT)
        doc_audit_report = store_and_create_doc(
            title="ISO 27001 Security Audit Working Paper",
            orig_filename="ISO27001_Audit_Working_Paper.txt",
            category="Audit",
            mime_type="text/plain",
            raw_bytes=SAMPLE_AUDIT_TEXT,
            owner=owner_carol
        )

        # Doc 4: R&D Blueprints (Carol owns, confidential)
        doc_blueprints = store_and_create_doc(
            title="Project Apollo Next-Gen Hardware Schematics",
            orig_filename="Apollo_Schematics_Confidential.pdf",
            category="Engineering",
            mime_type="application/pdf",
            raw_bytes=MINIMAL_PDF_BYTES,
            owner=owner_carol
        )

        # 3. Grant Permissions
        # Grant Sophia READ on Contract
        perm1 = DocumentPermission(
            document_id=doc_contract.id,
            user_id=viewer_sophia.id,
            permission_level="READ",
            granted_by_id=owner_marcus.id
        )
        db.add(perm1)
        db.commit()
        record_audit(
            db,
            action="GRANT_PERMISSION",
            target_type="PERMISSION",
            target_id=f"{doc_contract.id}:{viewer_sophia.id}",
            status="SUCCESS",
            user=owner_marcus,
            details={"recipient": viewer_sophia.email, "level": "READ"}
        )

        # Grant Sophia EDIT on ISO Audit Report
        perm2 = DocumentPermission(
            document_id=doc_audit_report.id,
            user_id=viewer_sophia.id,
            permission_level="EDIT",
            granted_by_id=owner_carol.id
        )
        db.add(perm2)
        db.commit()
        record_audit(
            db,
            action="GRANT_PERMISSION",
            target_type="PERMISSION",
            target_id=f"{doc_audit_report.id}:{viewer_sophia.id}",
            status="SUCCESS",
            user=owner_carol,
            details={"recipient": viewer_sophia.email, "level": "EDIT"}
        )

        # 4. Record a Refused Access Attempt (Simulated attack attempt)
        record_audit(
            db=db,
            action="ACCESS_READ",
            target_type="DOCUMENT",
            target_id=doc_salaries.id,
            status="REFUSED",
            user=viewer_david,
            reason=f"No access permission granted to user {viewer_david.email}",
            details={"attempted_by": viewer_david.email, "target_doc": doc_salaries.title}
        )

        print("[Seed] Seed data successfully committed.")
    finally:
        db.close()
