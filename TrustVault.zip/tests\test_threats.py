import io
import pytest
from tests.conftest import auth_header_for
from app.models import SecurityAlert, AuditLog


SAMPLE_PDF = b"%PDF-1.4 sample payload for threat tests"


def test_admin_cannot_snoop_confidential_document(client, users):
    """
    THREAT: Malicious or Compromised Administrator (Separation of Duty)
    In zero-trust architecture, an Administrator has system oversight and audit verification rights,
    but CANNOT download or inspect confidential document payloads unless explicitly granted in ACL.
    """
    admin = users["admin"]
    owner = users["owner1"]

    # Owner uploads confidential file
    file_tuple = ("file", ("executive_payroll.pdf", io.BytesIO(SAMPLE_PDF), "application/pdf"))
    res_up = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Executive Payroll", "category": "Salaries"},
        files=[file_tuple]
    )
    doc_id = res_up.json()["id"]

    # Admin attempts direct download without grant
    res_down = client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(admin))
    assert res_down.status_code == 403
    assert "Access denied" in res_down.json()["detail"]


def test_cross_tenant_permission_tampering(client, users):
    """
    THREAT: Attacker attempting to manipulate ACLs of a document they do not own.
    Owner 2 attempts to grant access to Owner 1's document.
    Must be blocked with 403.
    """
    owner1 = users["owner1"]
    owner2 = users["owner2"]
    viewer = users["viewer1"]

    file_tuple = ("file", ("board_minutes.pdf", io.BytesIO(SAMPLE_PDF), "application/pdf"))
    res_up = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner1),
        data={"title": "Board Minutes", "category": "General"},
        files=[file_tuple]
    )
    doc_id = res_up.json()["id"]

    # Owner 2 tries to grant Viewer 1 access to Owner 1's file
    res = client.post(
        f"/api/documents/{doc_id}/permissions",
        headers=auth_header_for(owner2),
        json={"user_email": viewer.email, "permission_level": "READ"}
    )
    assert res.status_code == 403
    assert "Only the document owner" in res.json()["detail"]


def test_unauthenticated_requests_strictly_rejected(client):
    """
    THREAT: Anonymous Probe / Information Leakage
    Unauthenticated requests to any document, permission, or audit endpoint must receive 401.
    """
    res1 = client.get("/api/documents")
    assert res1.status_code == 401

    res2 = client.get("/api/audit")
    assert res2.status_code == 401

    res3 = client.post("/api/documents/upload")
    assert res3.status_code == 401


def test_repeated_access_refusals_trigger_security_alert(client, users, db):
    """
    THREAT: Automated Brute-Force / Enumeration Attack
    When a user triggers multiple repeated access refusals, the system automatically
    creates a SecurityAlert in the database for SOC/Admin monitoring.
    """
    owner = users["owner1"]
    viewer = users["viewer1"]

    file_tuple = ("file", ("secret_file.pdf", io.BytesIO(SAMPLE_PDF), "application/pdf"))
    res_up = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Secret", "category": "General"},
        files=[file_tuple]
    )
    doc_id = res_up.json()["id"]

    # Viewer triggers 3 refused attempts in succession
    for _ in range(3):
        client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(viewer))

    # Verify a SecurityAlert was generated
    alert = db.query(SecurityAlert).filter(
        SecurityAlert.user_email == viewer.email,
        SecurityAlert.alert_type == "REPEATED_UNAUTHORIZED_ACCESS_ATTEMPTS"
    ).first()

    assert alert is not None
    assert "access refusals" in alert.description
