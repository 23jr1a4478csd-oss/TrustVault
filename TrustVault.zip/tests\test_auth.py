import pytest
from tests.conftest import auth_header_for


def test_user_registration_and_login(client):
    # Register new owner
    reg_res = client.post(
        "/api/auth/register",
        json={
            "email": "new_user@trustvault.internal",
            "password": "SecurePassword123!",
            "full_name": "New User",
            "role": "owner"
        }
    )
    assert reg_res.status_code == 201
    assert reg_res.json()["email"] == "new_user@trustvault.internal"

    # Login
    login_res = client.post(
        "/api/auth/login",
        json={"email": "new_user@trustvault.internal", "password": "SecurePassword123!"}
    )
    assert login_res.status_code == 200
    token = login_res.json()["access_token"]
    assert token is not None

    # Authenticated me endpoint
    me_res = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_res.status_code == 200
    assert me_res.json()["email"] == "new_user@trustvault.internal"


def test_failed_login_records_audit_and_returns_401(client, users, db):
    res = client.post(
        "/api/auth/login",
        json={"email": users["viewer1"].email, "password": "WrongPassword123!"}
    )
    assert res.status_code == 401
    assert "Invalid email or password" in res.json()["detail"]


def test_token_versioning_instant_revocation_on_logout(client, users):
    """
    SECURITY PROOF:
    Logging out bumps token_version in DB.
    The old JWT token is rejected synchronously even though its expiration timestamp is valid.
    """
    user = users["viewer1"]
    login_res = client.post(
        "/api/auth/login",
        json={"email": user.email, "password": "PassViewer1!"}
    )
    token = login_res.json()["access_token"]
    auth_header = {"Authorization": f"Bearer {token}"}

    # Verify token works
    res_before = client.get("/api/auth/me", headers=auth_header)
    assert res_before.status_code == 200

    # User logs out
    logout_res = client.post("/api/auth/logout", headers=auth_header)
    assert logout_res.status_code == 200

    # Next request with identical token MUST fail
    res_after = client.get("/api/auth/me", headers=auth_header)
    assert res_after.status_code == 401
    assert "revoked" in res_after.json()["detail"].lower()
