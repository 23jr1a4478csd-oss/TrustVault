from typing import Optional, List
from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.crypto import verify_audit_chain
from app.database import get_db
from app.models import User, AuditLog, Document
from app.schemas import AuditLogResponse, AuditVerificationResponse
from app.security import get_current_user, require_role

router = APIRouter(prefix="/api/audit", tags=["Audit Trail"])


@router.get("", response_model=List[AuditLogResponse])
def get_audit_trail(
    action: Optional[str] = Query(None, description="Filter by action"),
    status: Optional[str] = Query(None, description="Filter by status (SUCCESS, REFUSED, FAILED)"),
    target_id: Optional[str] = Query(None, description="Filter by target resource ID"),
    limit: int = Query(100, ge=1, le=1000),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Retrieves the audit trail.
    - Admin: Full visibility across the enterprise.
    - Owner: Visibility into all events on their documents + their own actions.
    - Viewer: Visibility into events pertaining to their own actions.
    """
    query = db.query(AuditLog)

    if current_user.role == "admin":
        pass  # Full enterprise view
    elif current_user.role == "owner":
        # Owner sees their own logs OR events targeting documents they own
        owned_doc_ids = db.query(Document.id).filter(
            Document.owner_id == current_user.id
        )

        query = query.filter(
            (AuditLog.user_id == current_user.id) |
            (AuditLog.target_id.in_(owned_doc_ids))
        )
    else:
        # Viewer sees only actions performed by themselves
        query = query.filter(AuditLog.user_id == current_user.id)

    if action:
        query = query.filter(AuditLog.action == action)
    if status:
        query = query.filter(AuditLog.status == status)
    if target_id:
        query = query.filter(AuditLog.target_id == target_id)

    logs = query.order_by(AuditLog.id.desc()).limit(limit).all()
    return logs


@router.get("/verify", response_model=AuditVerificationResponse)
def verify_audit_trail_integrity(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Performs full-chain cryptographic verification of the audit trail.
    Recalculates HMAC-SHA256 hashes and prev_hash links sequentially from Genesis.
    Returns proof of integrity or flags exact tampering location.
    """
    all_logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    is_valid, msg, failed_id = verify_audit_chain(all_logs)

    return AuditVerificationResponse(
        is_valid=is_valid,
        message=msg,
        verified_count=len(all_logs) if is_valid else (failed_id - 1 if failed_id else 0),
        failed_log_id=failed_id
    )
