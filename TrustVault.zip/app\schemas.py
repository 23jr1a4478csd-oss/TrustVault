from datetime import datetime
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, EmailStr, Field, ConfigDict


# Auth Schemas
class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)
    full_name: str = Field(..., min_length=2)
    role: str = Field("viewer", pattern="^(admin|owner|viewer)$")


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    email: str
    full_name: str
    role: str
    is_active: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


# Document Schemas
class DocumentUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None


class DocumentResponse(BaseModel):
    id: str
    title: str
    original_filename: str
    category: str
    mime_type: str
    file_size: int
    owner_id: int
    owner_name: Optional[str] = None
    owner_email: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    my_permission: Optional[str] = None  # "OWNER", "EDIT", "READ"

    model_config = ConfigDict(from_attributes=True)


# Permission Schemas
class DocumentPermissionCreate(BaseModel):
    user_email: EmailStr
    permission_level: str = Field(..., pattern="^(READ|EDIT)$")


class DocumentPermissionResponse(BaseModel):
    id: int
    document_id: str
    user_id: int
    user_email: str
    user_name: str
    permission_level: str
    granted_by_email: Optional[str] = None
    granted_at: datetime

    model_config = ConfigDict(from_attributes=True)


# Audit Schemas
class AuditLogResponse(BaseModel):
    id: int
    timestamp: str
    user_id: Optional[int]
    user_email: Optional[str]
    action: str
    target_type: str
    target_id: Optional[str]
    status: str
    reason: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    details: str
    prev_hash: str
    record_hash: str

    model_config = ConfigDict(from_attributes=True)


class AuditVerificationResponse(BaseModel):
    is_valid: bool
    message: str
    verified_count: int
    failed_log_id: Optional[int] = None


# Security Alert Schemas
class SecurityAlertResponse(BaseModel):
    id: int
    timestamp: str
    severity: str
    alert_type: str
    source_ip: Optional[str]
    user_email: Optional[str]
    description: str
    is_resolved: bool

    model_config = ConfigDict(from_attributes=True)
