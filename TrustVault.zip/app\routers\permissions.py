from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, Document, DocumentPermission
from app.schemas import DocumentPermissionCreate, DocumentPermissionResponse
from app.security import (
    get_current_user,
    verify_document_access,
    record_audit
)

router = APIRouter(prefix="/api/documents/{document_id}/permissions", tags=["Permissions"])


def serialize_perm(perm: DocumentPermission) -> DocumentPermissionResponse:
    return DocumentPermissionResponse(
        id=perm.id,
        document_id=perm.document_id,
        user_id=perm.user_id,
        user_email=perm.user.email if perm.user else "Unknown",
        user_name=perm.user.full_name if perm.user else "Unknown",
        permission_level=perm.permission_level,
        granted_by_email=perm.granted_by.email if perm.granted_by else None,
        granted_at=perm.granted_at
    )


@router.get("", response_model=List[DocumentPermissionResponse])
def get_document_permissions(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Lists all users granted access to this document.
    Strictly restricted to the document OWNER.
    """
    doc, _ = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="OWNER",
        db=db,
        request=request
    )

    perms = db.query(DocumentPermission).filter(DocumentPermission.document_id == document_id).all()
    return [serialize_perm(p) for p in perms]


@router.post("", response_model=DocumentPermissionResponse, status_code=status.HTTP_201_CREATED)
def grant_permission(
    document_id: str,
    payload: DocumentPermissionCreate,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Grants or updates access permission (READ or EDIT) for a named user.
    Strictly restricted to the document OWNER.
    """
    doc, _ = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="OWNER",
        db=db,
        request=request
    )

    recipient = db.query(User).filter(User.email == payload.user_email.lower()).first()
    if not recipient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with email '{payload.user_email}' does not exist in the system."
        )

    if recipient.id == doc.owner_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot grant permissions to the document owner (owner has inherent full access)."
        )

    existing_perm = db.query(DocumentPermission).filter(
        DocumentPermission.document_id == document_id,
        DocumentPermission.user_id == recipient.id
    ).first()

    if existing_perm:
        old_level = existing_perm.permission_level
        existing_perm.permission_level = payload.permission_level
        existing_perm.granted_by_id = current_user.id
        db.commit()
        db.refresh(existing_perm)

        record_audit(
            db=db,
            action="UPDATE_PERMISSION",
            target_type="PERMISSION",
            target_id=f"{document_id}:{recipient.id}",
            status="SUCCESS",
            user=current_user,
            details={
                "recipient_email": recipient.email,
                "old_level": old_level,
                "new_level": payload.permission_level
            },
            request=request
        )
        return serialize_perm(existing_perm)

    # Create new permission
    new_perm = DocumentPermission(
        document_id=document_id,
        user_id=recipient.id,
        permission_level=payload.permission_level,
        granted_by_id=current_user.id
    )
    db.add(new_perm)
    db.commit()
    db.refresh(new_perm)

    record_audit(
        db=db,
        action="GRANT_PERMISSION",
        target_type="PERMISSION",
        target_id=f"{document_id}:{recipient.id}",
        status="SUCCESS",
        user=current_user,
        details={
            "recipient_email": recipient.email,
            "permission_level": payload.permission_level
        },
        request=request
    )

    return serialize_perm(new_perm)


@router.delete("/{user_id}", status_code=status.HTTP_200_OK)
def revoke_permission(
    document_id: str,
    user_id: int,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Revokes access permission for a named user IMMEDIATELY.
    The permission record is deleted from the database in an atomic transaction.
    Any subsequent attempt by this user to access or download the document
    will be rejected synchronously.
    """
    doc, _ = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="OWNER",
        db=db,
        request=request
    )

    perm = db.query(DocumentPermission).filter(
        DocumentPermission.document_id == document_id,
        DocumentPermission.user_id == user_id
    ).first()

    if not perm:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Permission record not found for this user."
        )

    target_user = db.query(User).filter(User.id == user_id).first()
    target_email = target_user.email if target_user else f"user_{user_id}"

    db.delete(perm)
    db.commit()

    record_audit(
        db=db,
        action="REVOKE_PERMISSION",
        target_type="PERMISSION",
        target_id=f"{document_id}:{user_id}",
        status="SUCCESS",
        user=current_user,
        details={
            "revoked_user_id": user_id,
            "revoked_user_email": target_email,
            "revocation_time": "immediate"
        },
        request=request
    )

    return {"message": f"Access permission for user '{target_email}' successfully revoked immediately."}
