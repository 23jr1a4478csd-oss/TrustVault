import re
import os
from typing import Tuple
from app.config import MAX_FILE_SIZE_BYTES, ALLOWED_MIME_TYPES

# Magic byte signatures
MAGIC_SIGNATURES = {
    "application/pdf": [b"%PDF-"],
    "image/png": [b"\x89PNG\r\n\x1a\n"],
    "image/jpeg": [b"\xff\xd8\xff"],
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [b"PK\x03\x04"],
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [b"PK\x03\x04"],
}

# Forbidden executable signatures disguised as text
EXECUTABLE_HEADERS = [
    b"MZ",           # Windows DOS/PE
    b"\x7fELF",      # Linux ELF
    b"\xca\xfe\xba\xbe", # Java class
    b"#!",           # Unix shebang script
]


def sanitize_filename(filename: str) -> str:
    """
    Sanitizes an uploaded filename to prevent Path Traversal, Null Byte injection,
    and hidden file attacks.
    """
    # 1. Strip paths
    basename = os.path.basename(filename)
    basename = os.path.basename(basename.replace("\\", "/"))

    # 2. Remove null bytes and control chars
    basename = basename.replace("\x00", "").strip()

    # 3. Allow only safe characters [a-zA-Z0-9_.-]
    safe_name = re.sub(r'[^a-zA-Z0-9_.-]', '_', basename)

    # 4. Remove leading dots (prevent hidden files like .env or .bashrc)
    safe_name = safe_name.lstrip(".")

    if not safe_name:
        safe_name = "sanitized_document"

    return safe_name


def validate_file_content(filename: str, content: bytes, declared_mime: str) -> Tuple[bool, str, str]:
    """
    Validates file size, file extension, magic bytes, and checks for binary/script smuggling.
    Returns (is_valid, error_message, detected_mime).
    """
    # 1. File size check
    if len(content) == 0:
        return False, "Uploaded file is empty (0 bytes).", ""

    if len(content) > MAX_FILE_SIZE_BYTES:
        return False, f"File exceeds maximum allowed size of {MAX_FILE_SIZE_BYTES // (1024 * 1024)}MB.", ""

    # 2. Extension check
    ext = os.path.splitext(filename.lower())[1]
    matched_mime = None
    for mime, valid_exts in ALLOWED_MIME_TYPES.items():
        if ext in valid_exts:
            matched_mime = mime
            break

    if not matched_mime:
        allowed_list = ", ".join([ext for exts in ALLOWED_MIME_TYPES.values() for ext in exts])
        return False, f"File extension '{ext}' is not permitted. Allowed: {allowed_list}", ""

    # 3. Magic bytes inspection
    if matched_mime in MAGIC_SIGNATURES:
        signatures = MAGIC_SIGNATURES[matched_mime]
        valid_magic = any(content.startswith(sig) for sig in signatures)
        if not valid_magic:
            return (
                False,
                f"File content does not match extension '{ext}'. Magic bytes signature failed (MIME spoofing detected).",
                ""
            )
    elif matched_mime == "text/plain":
        # Check text safety
        # Must not contain null bytes
        if b"\x00" in content:
            return False, "Binary data with null bytes detected in plain text file.", ""

        # Must not match executable headers
        for bad_header in EXECUTABLE_HEADERS:
            if content.startswith(bad_header):
                return False, "Executable binary format disguised as text file.", ""

        # Must be valid UTF-8 or ASCII
        try:
            content.decode("utf-8")
        except UnicodeDecodeError:
            try:
                content.decode("latin-1")
            except Exception:
                return False, "File is not valid readable text.", ""

    return True, "", matched_mime
