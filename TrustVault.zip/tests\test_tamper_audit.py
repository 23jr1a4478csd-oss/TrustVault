import io
import pytest
from tests.conftest import auth_header_for
from app.crypto import verify_audit_chain
from app.models import AuditLog


SAMPLE_PDF = b"%PDF-1.4 audit tamper test payload"


def test_audit_records_all_critical_lifecycle_events(client, users, db):
    """
    Verifies that uploads, downloads, grants, revocations, and refused attempts
    are all captured in the audit log.
    """
    owner = users["owner1"]
    viewer = users["viewer1"]

    # 1. Upload
    file_tuple = ("file", ("audit_doc.pdf", io.BytesIO(SAMPLE_PDF), "application/pdf"))
    res_up = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Audit Doc", "category": "Audit"},
        files=[file_tuple]
    )
    doc_id = res_up.json()["id"]

    # 2. Grant
    client.post(
        f"/api/documents/{doc_id}/permissions",
        headers=auth_header_for(owner),
        json={"user_email": viewer.email, "permission_level": "READ"}
    )

    # 3. Download
    client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(viewer))

    # 4. Revoke
    client.delete(f"/api/documents/{doc_id}/permissions/{viewer.id}", headers=auth_header_for(owner))

    # 5. Refused Download
    client.get(f"/api/documents/{doc_id}/download", headers=auth_header_for(viewer))

    # Check database logs
    logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    actions = [l.action for l in logs]

    assert "UPLOAD" in actions
    assert "GRANT_PERMISSION" in actions
    assert "DOWNLOAD" in actions
    assert "REVOKE_PERMISSION" in actions
    assert "ACCESS_READ" in actions

    # Check full chain integrity
    is_valid, msg, failed_id = verify_audit_chain(logs)
    assert is_valid is True
    assert failed_id is None


def test_tampered_audit_record_fails_verification(client, users, db):
    """
    SECURITY PROOF (NON-NEGOTIABLE #2):
    Simulates a rogue admin or SQL-injection attacker modifying an audit record
    (e.g., changing the user_email to frame someone else or deleting evidence).
    The HMAC-SHA256 hash verification MUST fail and identify the exact tampered row.
    """
    owner = users["owner1"]

    # Create an upload event
    file_tuple = ("file", ("tamper_doc.pdf", io.BytesIO(SAMPLE_PDF), "application/pdf"))
    client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Tamper Doc", "category": "Audit"},
        files=[file_tuple]
    )

    logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    assert len(logs) > 0
    target_log = logs[-1]
    tampered_id = target_log.id

    # Tamper with the row directly (simulating database tampering)
    target_log.user_email = "innocent_victim@company.com"
    db.commit()

    # Re-verify chain
    refetched_logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    is_valid, msg, failed_id = verify_audit_chain(refetched_logs)

    assert is_valid is False
    assert failed_id == tampered_id
    assert "Tampering detected" in msg


def test_broken_hash_chain_link_fails_verification(client, users, db):
    """
    Simulates an attacker trying to delete a middle record from the audit log.
    Because row[i].prev_hash points to deleted row[i-1].record_hash, the link breaks!
    """
    owner = users["owner1"]

    # Generate 3 events
    for i in range(3):
        file_tuple = ("file", (f"chain_{i}.pdf", io.BytesIO(SAMPLE_PDF), "application/pdf"))
        client.post(
            "/api/documents/upload",
            headers=auth_header_for(owner),
            data={"title": f"Chain Doc {i}", "category": "Audit"},
            files=[file_tuple]
        )

    logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    assert len(logs) >= 3

    # Rogue deletion of middle record
    middle_log = logs[-2]
    db.delete(middle_log)
    db.commit()

    # Verify
    surviving_logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    is_valid, msg, failed_id = verify_audit_chain(surviving_logs)

    assert is_valid is False
    assert "Broken chain" in msg
