import os
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base, get_db
from app.main import app
from app.models import User
from app.security import hash_password, create_access_token

# Test database
TEST_DB_URL = "sqlite:///./test_trustvault.db"
test_engine = create_engine(TEST_DB_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=test_engine)


@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    Base.metadata.drop_all(bind=test_engine)
    Base.metadata.create_all(bind=test_engine)
    yield
    Base.metadata.drop_all(bind=test_engine)
    if os.path.exists("./test_trustvault.db"):
        try:
            os.remove("./test_trustvault.db")
        except Exception:
            pass


@pytest.fixture
def db():
    connection = test_engine.connect()
    transaction = connection.begin()
    session = TestingSessionLocal(bind=connection)

    yield session

    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture
def client(db):
    def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()


@pytest.fixture
def users(db):
    """
    Creates isolated test users with distinct roles.
    """
    admin = User(
        email="test_admin@tv.internal",
        hashed_password=hash_password("PassAdmin123!"),
        full_name="Test Admin",
        role="admin",
        token_version=1,
        is_active=True
    )
    owner1 = User(
        email="test_owner1@tv.internal",
        hashed_password=hash_password("PassOwner1!"),
        full_name="Owner Alice",
        role="owner",
        token_version=1,
        is_active=True
    )
    owner2 = User(
        email="test_owner2@tv.internal",
        hashed_password=hash_password("PassOwner2!"),
        full_name="Owner Bob",
        role="owner",
        token_version=1,
        is_active=True
    )
    viewer1 = User(
        email="test_viewer1@tv.internal",
        hashed_password=hash_password("PassViewer1!"),
        full_name="Viewer Charlie",
        role="viewer",
        token_version=1,
        is_active=True
    )
    viewer2 = User(
        email="test_viewer2@tv.internal",
        hashed_password=hash_password("PassViewer2!"),
        full_name="Viewer Diana",
        role="viewer",
        token_version=1,
        is_active=True
    )

    db.add_all([admin, owner1, owner2, viewer1, viewer2])
    db.commit()

    return {
        "admin": admin,
        "owner1": owner1,
        "owner2": owner2,
        "viewer1": viewer1,
        "viewer2": viewer2
    }


def auth_header_for(user: User) -> dict:
    token = create_access_token({"sub": str(user.id), "role": user.role, "token_version": user.token_version})
    return {"Authorization": f"Bearer {token}"}
