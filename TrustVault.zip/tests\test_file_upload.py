import io
import pytest
from tests.conftest import auth_header_for


def test_magic_bytes_enforcement_rejects_disguised_executable(client, users):
    """
    SECURITY PROOF (MIME Confusion / Binary Disguise):
    Attacker uploads a Windows PE executable binary with a .pdf extension.
    The server inspects magic bytes and MUST reject it with 400 Bad Request.
    """
    owner = users["owner1"]
    fake_exe = b"MZ\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00\xff\xff\x00\x00This program cannot be run in DOS mode."
    file_tuple = ("file", ("trojan.pdf", io.BytesIO(fake_exe), "application/pdf"))

    res = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Invoice", "category": "General"},
        files=[file_tuple]
    )

    assert res.status_code == 400
    assert "Magic bytes signature failed" in res.json()["detail"]


def test_reject_null_bytes_in_text_file(client, users):
    """
    SECURITY PROOF:
    Text file containing null bytes (binary injection) is rejected.
    """
    owner = users["owner1"]
    binary_text = b"Normal line\x00Malicious hidden shellcode"
    file_tuple = ("file", ("notes.txt", io.BytesIO(binary_text), "text/plain"))

    res = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Notes", "category": "General"},
        files=[file_tuple]
    )

    assert res.status_code == 400
    assert "null bytes detected" in res.json()["detail"]


def test_path_traversal_filename_sanitization(client, users):
    """
    SECURITY PROOF (Path Traversal Prevention):
    Attacker tries path traversal sequences in filename: ../../../../etc/passwd
    The server sanitizes it, stripping directories and storing it safely with UUID.
    """
    owner = users["owner1"]
    clean_pdf = b"%PDF-1.4 test safe content"
    malicious_filename = "../../../../etc/passwd.pdf"
    file_tuple = ("file", (malicious_filename, io.BytesIO(clean_pdf), "application/pdf"))

    res = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Traversal Test", "category": "General"},
        files=[file_tuple]
    )

    assert res.status_code == 201
    data = res.json()
    assert "/" not in data["original_filename"]
    assert ".." not in data["original_filename"]
    assert data["original_filename"] == "passwd.pdf"


def test_empty_file_rejected(client, users):
    """
    Rejects 0-byte file upload.
    """
    owner = users["owner1"]
    file_tuple = ("file", ("empty.pdf", io.BytesIO(b""), "application/pdf"))

    res = client.post(
        "/api/documents/upload",
        headers=auth_header_for(owner),
        data={"title": "Empty", "category": "General"},
        files=[file_tuple]
    )

    assert res.status_code == 400
    assert "0 bytes" in res.json()["detail"]
