import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "vault_storage"

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Security Secrets (In production these are loaded via environment variables or secret manager)
SECRET_KEY = os.getenv("TRUSTVAULT_SECRET_KEY", "tv-sec-f78a0d9e8c4b1234567890abcdef1234567890abcdef1234567890abcdef")
AUDIT_HMAC_KEY = os.getenv("TRUSTVAULT_AUDIT_KEY", "tv-audit-99a8b7c6d5e4f3a2b10987654321fedcba0987654321fedcba0987654321fedc")
MASTER_ENCRYPTION_KEY = os.getenv(
    "TRUSTVAULT_MASTER_KEY",
    # 32 bytes hex = 64 hex chars
    "a1b2c3d4e5f60718293a4b5c6d7e8f90123456789abcdef0123456789abcdef0"
)

# JWT Configuration
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "120"))
ALGORITHM = "HS256"

# Database Configuration
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR / 'trustvault.db'}")

# Upload Restrictions
MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024  # 25 MB
ALLOWED_MIME_TYPES = {
    "application/pdf": [".pdf"],
    "text/plain": [".txt", ".md", ".csv", ".json"],
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
    "image/png": [".png"],
    "image/jpeg": [".jpg", ".jpeg"],
}
