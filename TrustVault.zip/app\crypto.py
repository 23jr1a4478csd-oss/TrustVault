import hashlib
import hmac
import json
import os
from typing import Tuple, List, Optional
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from app.config import AUDIT_HMAC_KEY, MASTER_ENCRYPTION_KEY

# Convert master key from hex to 32 bytes
MASTER_KEY_BYTES = bytes.fromhex(MASTER_ENCRYPTION_KEY)
AUDIT_KEY_BYTES = AUDIT_HMAC_KEY.encode("utf-8")
GENESIS_HASH = "0" * 64


def encrypt_data(plaintext: bytes) -> Tuple[bytes, str]:
    """
    Encrypts raw bytes using AES-256-GCM.
    Returns (ciphertext_with_tag, nonce_hex).
    AES-256-GCM provides confidentiality and integrity (AEAD).
    """
    aesgcm = AESGCM(MASTER_KEY_BYTES)
    nonce = os.urandom(12)  # Standard 96-bit nonce for GCM
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)
    return ciphertext, nonce.hex()


def decrypt_data(ciphertext: bytes, nonce_hex: str) -> bytes:
    """
    Decrypts ciphertext using AES-256-GCM and verifies authentication tag.
    Raises InvalidTag if ciphertext or nonce has been altered.
    """
    aesgcm = AESGCM(MASTER_KEY_BYTES)
    nonce = bytes.fromhex(nonce_hex)
    return aesgcm.decrypt(nonce, ciphertext, None)


def canonical_log_string(
    log_id: int,
    timestamp: str,
    user_id: Optional[int],
    user_email: Optional[str],
    action: str,
    target_type: str,
    target_id: Optional[str],
    status: str,
    reason: Optional[str],
    ip_address: Optional[str],
    details: str,
    prev_hash: str
) -> str:
    """
    Generates a deterministic canonical string representation of an audit log entry
    for HMAC computation. Protects all identifying and contextual fields against tampering.
    """
    return (
        f"{log_id}|{timestamp}|{user_id or 'ANON'}|{user_email or 'NONE'}|{action}|"
        f"{target_type}|{target_id or 'NONE'}|{status}|{reason or 'NONE'}|"
        f"{ip_address or 'NONE'}|{details}|{prev_hash}"
    )


def compute_audit_hash(
    log_id: int,
    timestamp: str,
    user_id: Optional[int],
    user_email: Optional[str],
    action: str,
    target_type: str,
    target_id: Optional[str],
    status: str,
    reason: Optional[str],
    ip_address: Optional[str],
    details: str,
    prev_hash: str
) -> str:
    """
    Computes HMAC-SHA256 signature over the canonical log entry representation
    chained to the previous hash.
    """
    canonical_data = canonical_log_string(
        log_id=log_id,
        timestamp=timestamp,
        user_id=user_id,
        user_email=user_email,
        action=action,
        target_type=target_type,
        target_id=target_id,
        status=status,
        reason=reason,
        ip_address=ip_address,
        details=details,
        prev_hash=prev_hash
    )
    return hmac.new(
        AUDIT_KEY_BYTES,
        canonical_data.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def verify_audit_chain(logs: List[any]) -> Tuple[bool, str, Optional[int]]:
    """
    Iterates through audit logs and verifies the entire cryptographic chain.
    Returns (is_valid, message, failed_log_id).
    """
    if not logs:
        return True, "Audit log is empty; chain is intact.", None

    expected_prev = GENESIS_HASH

    for i, log in enumerate(logs):
        # 1. Verify prev_hash link
        if not hmac.compare_digest(log.prev_hash, expected_prev):
            return (
                False,
                f"Broken chain at log entry ID {log.id}: prev_hash does not match previous entry's record_hash.",
                log.id
            )

        # 2. Recompute record_hash and verify signature
        recalculated_hash = compute_audit_hash(
            log_id=log.id,
            timestamp=log.timestamp,
            user_id=log.user_id,
            user_email=log.user_email,
            action=log.action,
            target_type=log.target_type,
            target_id=log.target_id,
            status=log.status,
            reason=log.reason,
            ip_address=log.ip_address,
            details=log.details or "{}",
            prev_hash=log.prev_hash
        )

        if not hmac.compare_digest(log.record_hash, recalculated_hash):
            return (
                False,
                f"Tampering detected at log entry ID {log.id}: signature mismatch (content or timestamp was modified).",
                log.id
            )

        # Advance expected prev_hash
        expected_prev = log.record_hash

    return True, f"All {len(logs)} audit records cryptographically verified with zero discrepancies.", None
