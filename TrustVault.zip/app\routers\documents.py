import os
import uuid
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File, Form, Query, Request, Response
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_

from app.config import UPLOAD_DIR
from app.crypto import encrypt_data, decrypt_data
from app.database import get_db
from app.file_validator import sanitize_filename, validate_file_content
from app.models import User, Document, DocumentPermission, AuditLog
from app.schemas import DocumentResponse, DocumentUpdate
from app.security import (
    get_current_user,
    verify_document_access,
    record_audit,
    require_role
)

router = APIRouter(prefix="/api/documents", tags=["Documents"])


def serialize_doc_response(doc: Document, current_user: User, perm_level: Optional[str] = None) -> DocumentResponse:
    if perm_level is None:
        if doc.owner_id == current_user.id:
            perm_level = "OWNER"
        else:
            perm_obj = next((p for p in doc.permissions if p.user_id == current_user.id), None)
            perm_level = perm_obj.permission_level if perm_obj else None

    return DocumentResponse(
        id=doc.id,
        title=doc.title,
        original_filename=doc.original_filename,
        category=doc.category,
        mime_type=doc.mime_type,
        file_size=doc.file_size,
        owner_id=doc.owner_id,
        owner_name=doc.owner.full_name if doc.owner else "Unknown",
        owner_email=doc.owner.email if doc.owner else "Unknown",
        created_at=doc.created_at,
        updated_at=doc.updated_at,
        my_permission=perm_level
    )


@router.post("/upload", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    request: Request,
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
    category: Optional[str] = Form("General"),
    current_user: User = Depends(require_role("owner", "admin")),
    db: Session = Depends(get_db)
):
    """
    Uploads, validates, encrypts (AES-256-GCM), and registers a new document.
    Enforces strict magic byte validation, filename sanitization, and audit logging.
    """
    raw_filename = file.filename or "unnamed_document"
    clean_filename = sanitize_filename(raw_filename)
    file_bytes = await file.read()

    # 1. Strict Content & Magic Byte Validation
    is_valid, err_msg, detected_mime = validate_file_content(
        filename=clean_filename,
        content=file_bytes,
        declared_mime=file.content_type or ""
    )
    if not is_valid:
        record_audit(
            db=db,
            action="UPLOAD_FAILED",
            target_type="DOCUMENT",
            target_id=clean_filename,
            status="FAILED",
            user=current_user,
            reason=err_msg,
            details={"original_filename": raw_filename, "size": len(file_bytes)},
            request=request
        )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err_msg)

    # 2. Authenticated Encryption at Rest (AES-256-GCM)
    ciphertext, nonce_hex = encrypt_data(file_bytes)
    stored_name = f"{uuid.uuid4().hex}.enc"
    storage_path = UPLOAD_DIR / stored_name

    with open(storage_path, "wb") as f:
        f.write(ciphertext)

    # 3. Store metadata in database
    doc_title = title.strip() if title and title.strip() else clean_filename
    document = Document(
        title=doc_title,
        original_filename=clean_filename,
        stored_filename=stored_name,
        category=category.strip() if category else "General",
        mime_type=detected_mime,
        file_size=len(file_bytes),
        owner_id=current_user.id,
        encryption_nonce=nonce_hex,
        is_deleted=False
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    # 4. Audit Trail Entry
    record_audit(
        db=db,
        action="UPLOAD",
        target_type="DOCUMENT",
        target_id=document.id,
        status="SUCCESS",
        user=current_user,
        details={
            "title": document.title,
            "filename": clean_filename,
            "mime_type": detected_mime,
            "size_bytes": len(file_bytes)
        },
        request=request
    )

    return serialize_doc_response(document, current_user, "OWNER")


@router.get("", response_model=List[DocumentResponse])
def list_documents(
    search: Optional[str] = Query(None, description="Search by title or filename"),
    category: Optional[str] = Query(None, description="Filter by category"),
    owner_email: Optional[str] = Query(None, description="Filter by owner email"),
    start_date: Optional[str] = Query(None, description="Start date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="End date (YYYY-MM-DD)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Search and retrieve documents.
    Enforces strict Zero-Trust isolation: Users only see documents they own or
    have been explicitly granted active permissions to.
    """
    query = db.query(Document).filter(Document.is_deleted == False)

    # Access boundary:
    # User sees documents where they are the owner OR they possess an active grant in DocumentPermission
    granted_doc_ids = db.query(DocumentPermission.document_id).filter(
        DocumentPermission.user_id == current_user.id
    )

    query = query.filter(
        or_(
            Document.owner_id == current_user.id,
            Document.id.in_(granted_doc_ids)
        )
    )

    # Filters
    if search:
        search_fmt = f"%{search.strip()}%"
        query = query.filter(
            or_(
                Document.title.ilike(search_fmt),
                Document.original_filename.ilike(search_fmt)
            )
        )

    if category:
        query = query.filter(Document.category.ilike(category.strip()))

    if owner_email:
        query = query.join(Document.owner).filter(User.email.ilike(owner_email.strip()))

    if start_date:
        try:
            dt_start = datetime.fromisoformat(start_date)
            query = query.filter(Document.created_at >= dt_start)
        except ValueError:
            pass

    if end_date:
        try:
            dt_end = datetime.fromisoformat(end_date)
            query = query.filter(Document.created_at <= dt_end)
        except ValueError:
            pass

    docs = query.order_by(Document.created_at.desc()).all()
    return [serialize_doc_response(d, current_user) for d in docs]


@router.get("/{document_id}", response_model=DocumentResponse)
def get_document_metadata(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Retrieves document metadata after real-time authorization check.
    """
    doc, perm_level = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="READ",
        db=db,
        request=request
    )

    record_audit(
        db=db,
        action="READ_METADATA",
        target_type="DOCUMENT",
        target_id=document_id,
        status="SUCCESS",
        user=current_user,
        details={"permission": perm_level},
        request=request
    )

    return serialize_doc_response(doc, current_user, perm_level)


@router.get("/{document_id}/download")
def download_document(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Downloads and decrypts the document file.
    The authorization decision is made on the server synchronously right here.
    If access was revoked, the request is immediately rejected and logged.
    """
    # 1. Authorize against current DB state
    doc, perm_level = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="READ",
        db=db,
        request=request
    )

    # 2. Locate encrypted storage
    storage_path = UPLOAD_DIR / doc.stored_filename
    if not storage_path.exists():
        record_audit(
            db=db,
            action="DOWNLOAD_FAILED",
            target_type="DOCUMENT",
            target_id=document_id,
            status="FAILED",
            user=current_user,
            reason="Stored payload missing on storage volume",
            request=request
        )
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Storage payload not found.")

    with open(storage_path, "rb") as f:
        ciphertext = f.read()

    # 3. Decrypt and verify AEAD integrity tag
    try:
        decrypted_bytes = decrypt_data(ciphertext, doc.encryption_nonce)
    except Exception as e:
        record_audit(
            db=db,
            action="DOWNLOAD_FAILED",
            target_type="DOCUMENT",
            target_id=document_id,
            status="FAILED",
            user=current_user,
            reason=f"Decryption integrity failure: {str(e)}",
            request=request
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Cryptographic verification failed on file retrieval."
        )

    # 4. Audit log entry
    record_audit(
        db=db,
        action="DOWNLOAD",
        target_type="DOCUMENT",
        target_id=document_id,
        status="SUCCESS",
        user=current_user,
        details={"filename": doc.original_filename, "bytes": len(decrypted_bytes)},
        request=request
    )

    # 5. Safe streaming with anti-XSS headers
    safe_filename = doc.original_filename.replace('"', '\\"')
    headers = {
        "Content-Disposition": f'attachment; filename="{safe_filename}"',
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache"
    }

    return Response(
        content=decrypted_bytes,
        media_type=doc.mime_type or "application/octet-stream",
        headers=headers
    )


@router.put("/{document_id}", response_model=DocumentResponse)
async def update_document(
    document_id: str,
    request: Request,
    title: Optional[str] = Form(None),
    category: Optional[str] = Form(None),
    file: Optional[UploadFile] = File(None),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Updates document metadata or replaces file content.
    Requires at least EDIT permission (or OWNER).
    """
    doc, perm_level = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="EDIT",
        db=db,
        request=request
    )

    changes = {}

    if title and title.strip():
        doc.title = title.strip()
        changes["title"] = doc.title

    if category and category.strip():
        doc.category = category.strip()
        changes["category"] = doc.category

    if file:
        raw_filename = file.filename or doc.original_filename
        clean_filename = sanitize_filename(raw_filename)
        file_bytes = await file.read()

        is_valid, err_msg, detected_mime = validate_file_content(
            filename=clean_filename,
            content=file_bytes,
            declared_mime=file.content_type or ""
        )
        if not is_valid:
            record_audit(
                db=db,
                action="EDIT_FAILED",
                target_type="DOCUMENT",
                target_id=document_id,
                status="FAILED",
                user=current_user,
                reason=err_msg,
                request=request
            )
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err_msg)

        # Re-encrypt with new fresh nonce
        ciphertext, nonce_hex = encrypt_data(file_bytes)
        storage_path = UPLOAD_DIR / doc.stored_filename
        with open(storage_path, "wb") as f:
            f.write(ciphertext)

        doc.original_filename = clean_filename
        doc.mime_type = detected_mime
        doc.file_size = len(file_bytes)
        doc.encryption_nonce = nonce_hex
        changes["content_replaced"] = True
        changes["new_size"] = len(file_bytes)

    doc.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(doc)

    record_audit(
        db=db,
        action="EDIT",
        target_type="DOCUMENT",
        target_id=document_id,
        status="SUCCESS",
        user=current_user,
        details=changes,
        request=request
    )

    return serialize_doc_response(doc, current_user, perm_level)


@router.delete("/{document_id}", status_code=status.HTTP_200_OK)
def delete_document(
    document_id: str,
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Deletes a document. Strictly restricted to the document OWNER.
    Performs soft deletion and destroys the encrypted storage payload.
    """
    doc, _ = verify_document_access(
        document_id=document_id,
        user=current_user,
        required_level="OWNER",
        db=db,
        request=request
    )

    # Securely delete physical file
    storage_path = UPLOAD_DIR / doc.stored_filename
    if storage_path.exists():
        try:
            os.remove(storage_path)
        except Exception:
            pass

    doc.is_deleted = True
    db.commit()

    record_audit(
        db=db,
        action="DELETE",
        target_type="DOCUMENT",
        target_id=document_id,
        status="SUCCESS",
        user=current_user,
        details={"title": doc.title, "filename": doc.original_filename},
        request=request
    )

    return {"message": f"Document '{doc.title}' successfully deleted."}
