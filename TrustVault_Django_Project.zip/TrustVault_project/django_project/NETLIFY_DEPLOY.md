# Netlify frontend deployment notes

The preserved static frontend is located at `../existing_project/netlify_deploy/` relative to this Django project folder. Copy that folder's contents to a dedicated frontend repository or configure Netlify's base directory to the frontend folder in your GitHub repository.

A Netlify URL cannot be created from this local archive alone. You must sign in to Netlify, import the Git repository, select the frontend publish directory, and deploy. The Django API must be hosted separately on a Python-capable host, with PostgreSQL configured there. Before deploying the preserved frontend, inspect `js/app.js` and configure its API base URL to your deployed backend; never place database passwords or Django secret keys in frontend code.
