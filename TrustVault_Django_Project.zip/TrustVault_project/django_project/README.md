# TrustVault — Django starter

TrustVault is a security-focused document-sharing prototype built with Python, Django, PostgreSQL, Bootstrap, and GitHub. This repository includes a Django backend and preserves the uploaded project's original implementation separately under `../existing_project/` for reference.

## Features in this starter
- Home, registration, login, dashboard, document list/upload/download, and administrator audit pages.
- Django's built-in User authentication, CSRF protection, password validators, sessions, and admin.
- Planned roles: Administrator, Document Owner, Viewer.
- File uploads stored outside the public web directory; downloads go through an authenticated view.
- Environment-driven settings, PostgreSQL configuration, security checklist, and tests.
- A separate existing `netlify_deploy/` frontend is preserved under `existing_project/netlify_deploy/`.

## Setup (Python 3.11+ recommended)
1. Create and activate a virtual environment:
   - Windows PowerShell: `py -m venv .venv; .\.venv\Scripts\Activate.ps1`
   - macOS/Linux: `python3 -m venv .venv && source .venv/bin/activate`
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`, then set a unique `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=True` for local development, `DJANGO_ALLOWED_HOSTS=127.0.0.1,localhost`, and `DATABASE_URL`.
4. Install and start PostgreSQL, create a database and user, and update `DATABASE_URL`. If `DATABASE_URL` is omitted, local development falls back to SQLite; production should use PostgreSQL.
5. Ensure `PRIVATE_UPLOAD_ROOT` points to a directory outside the public web root. Keep it writable only by the application user.
6. Run migrations and create an administrator:
   `python manage.py migrate`
   `python manage.py createsuperuser`
7. Start the development server: `python manage.py runserver`
8. Visit `http://127.0.0.1:8000/`.

## Tests and checks
- Run: `python manage.py test`
- Run: `python manage.py check --deploy` (review every warning before production).
- Tests are starter checks, not a full security audit. Do not claim production security until tests cover permission boundaries, file validation, upload/download behavior, and deployment settings.

## Deployment
Django requires a Python-capable application host; Netlify does not run a conventional Django server. Deploy the Django backend to a supported Python host and PostgreSQL to a managed database provider. Set environment variables in the backend host, use HTTPS, configure allowed hosts/CSRF origins, run migrations, and configure persistent private file storage. The preserved static frontend can be deployed to Netlify, but it must be configured to call the deployed API and must not contain secrets. Netlify hosting does not itself deploy this Django application.

## Important security notes
- New public registrations can choose Document Owner or Viewer; they cannot self-register as Administrator.
- Sharing/permission-management UI is not yet implemented. Document permissions can be created via Django admin or code.
- Uploaded content type is user-supplied metadata; stronger file-signature inspection, malware scanning, quotas, and hardened storage are required before production.
- The starter has not been run in this environment; execute the tests in your configured environment before relying on behavior.
