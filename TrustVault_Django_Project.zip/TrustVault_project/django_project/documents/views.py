import mimetypes
from pathlib import Path
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods
from accounts.models import Profile
from audit.models import AuditEvent
from .forms import DocumentUploadForm
from .models import Document, DocumentPermission

def can_view(user, doc):
    if user.is_staff or doc.owner_id == user.id:
        return True
    profile = getattr(user, "profile", None)
    if profile and profile.role == Profile.Role.ADMINISTRATOR:
        return True
    return DocumentPermission.objects.filter(document=doc, user=user, can_view=True).exists()

@login_required
def document_list(request):
    if request.user.is_staff or (getattr(getattr(request.user, "profile", None), "role", "") == "administrator"):
        docs = Document.objects.all()
    else:
        docs = Document.objects.filter(owner=request.user) | Document.objects.filter(permissions__user=request.user, permissions__can_view=True)
    return render(request, "documents/list.html", {"documents": docs.distinct()})

@login_required
@require_http_methods(["GET", "POST"])
def upload(request):
    profile = getattr(request.user, "profile", None)
    if not (request.user.is_staff or (profile and profile.role in {Profile.Role.OWNER, Profile.Role.ADMINISTRATOR})):
        messages.error(request, "Only document owners can upload files.")
        return redirect("documents:list")
    form = DocumentUploadForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        doc = form.save(commit=False)
        doc.owner = request.user
        doc.original_filename = request.FILES["file"].name[:255]
        doc.size_bytes = request.FILES["file"].size
        doc.content_type = getattr(request.FILES["file"], "content_type", "")[:120]
        doc.save()
        AuditEvent.objects.create(actor=request.user, action="document_uploaded", document=doc, detail="Document uploaded")
        messages.success(request, "Document uploaded to private storage.")
        return redirect("documents:list")
    return render(request, "documents/upload.html", {"form": form})

@login_required
def download(request, pk):
    doc = get_object_or_404(Document, pk=pk)
    if not can_view(request.user, doc):
        AuditEvent.objects.create(actor=request.user, action="document_access_denied", document=doc, detail="Unauthorized download attempt")
        raise Http404("Document not found")
    allowed = doc.owner_id == request.user.id or request.user.is_staff or DocumentPermission.objects.filter(document=doc, user=request.user, can_download=True).exists()
    if not allowed:
        raise Http404("Document not found")
    try:
        handle = doc.file.open("rb")
    except (OSError, ValueError):
        raise Http404("Document file unavailable")
    AuditEvent.objects.create(actor=request.user, action="document_downloaded", document=doc, detail="Document downloaded")
    response = FileResponse(handle, as_attachment=True, filename=Path(doc.original_filename).name)
    response["X-Content-Type-Options"] = "nosniff"
    return response
