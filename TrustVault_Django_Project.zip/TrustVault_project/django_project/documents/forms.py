from django import forms
from .models import Document
ALLOWED_EXTENSIONS = {".pdf", ".txt", ".docx", ".xlsx", ".png", ".jpg", ".jpeg"}
MAX_FILE_SIZE = 10 * 1024 * 1024

class DocumentUploadForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = ["title", "file"]
    def clean_file(self):
        f = self.cleaned_data["file"]
        import os
        ext = os.path.splitext(f.name)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            raise forms.ValidationError("File type not allowed. Allowed: PDF, TXT, DOCX, XLSX, PNG, JPG.")
        if f.size > MAX_FILE_SIZE:
            raise forms.ValidationError("Maximum file size is 10 MB.")
        return f
