from django.contrib.auth.models import User
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse
from accounts.models import Profile
from .models import Document, DocumentPermission

class PrivateDocumentTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(username="owner", password="Strong-Test-Pass-123!")
        self.owner.profile.role = Profile.Role.OWNER
        self.owner.profile.save()
        self.viewer = User.objects.create_user(username="viewer", password="Strong-Test-Pass-123!")
        self.viewer.profile.role = Profile.Role.VIEWER
        self.viewer.profile.save()
        self.doc = Document.objects.create(owner=self.owner, title="Private", original_filename="private.txt",
            file=SimpleUploadedFile("private.txt", b"secret contents", content_type="text/plain"), size_bytes=15)
    def test_anonymous_user_cannot_download(self):
        response = self.client.get(reverse("documents:download", args=[self.doc.pk]))
        self.assertIn(response.status_code, (302, 403))
    def test_unpermitted_viewer_cannot_download(self):
        self.client.login(username="viewer", password="Strong-Test-Pass-123!")
        response = self.client.get(reverse("documents:download", args=[self.doc.pk]))
        self.assertEqual(response.status_code, 404)
    def test_owner_can_download(self):
        self.client.login(username="owner", password="Strong-Test-Pass-123!")
        response = self.client.get(reverse("documents:download", args=[self.doc.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Disposition"].split(";")[0], "attachment")
    def test_viewer_with_download_permission_can_download(self):
        DocumentPermission.objects.create(document=self.doc, user=self.viewer, can_view=True, can_download=True)
        self.client.login(username="viewer", password="Strong-Test-Pass-123!")
        response = self.client.get(reverse("documents:download", args=[self.doc.pk]))
        self.assertEqual(response.status_code, 200)
