from django.urls import path
from . import views
app_name = "documents"
urlpatterns = [
    path("", views.document_list, name="list"),
    path("upload/", views.upload, name="upload"),
    path("<int:pk>/download/", views.download, name="download"),
]
