import uuid
from pathlib import Path
from django.conf import settings
from django.db import models
from django.utils import timezone

def private_upload_path(instance, filename):
    # Randomized storage name; original filename is kept as metadata only.
    suffix = Path(filename).suffix[:12]
    return f"{timezone.now():%Y/%m}/{uuid.uuid4().hex}{suffix}"

class Document(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="owned_documents")
    title = models.CharField(max_length=180)
    original_filename = models.CharField(max_length=255)
    file = models.FileField(upload_to=private_upload_path)
    content_type = models.CharField(max_length=120, blank=True)
    size_bytes = models.PositiveBigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.title

class DocumentPermission(models.Model):
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name="permissions")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="document_permissions")
    can_view = models.BooleanField(default=True)
    can_download = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["document", "user"], name="unique_document_user_permission")]
