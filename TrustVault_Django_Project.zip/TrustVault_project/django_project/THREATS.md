# TrustVault threat checklist

Status: initial checklist, not a security certification. Mark an item complete only after evidence and tests exist.

## Identity and authentication
- [ ] Enforce strong passwords and password validation.
- [ ] Protect login/register/logout with CSRF and secure session settings.
- [ ] Add login throttling, brute-force detection, and monitoring.
- [ ] Define account recovery and email verification flows.
- [ ] Ensure only trusted operators can grant Administrator role.

## Authorization and tenant boundaries
- [ ] Test that anonymous users cannot list or download private files.
- [ ] Test owner-only upload and owner/admin access boundaries.
- [ ] Test Viewer permissions for listing, viewing, and downloading separately.
- [ ] Add a user-facing, auditable sharing/revocation workflow.
- [ ] Prevent object-ID guessing from leaking whether a document exists.

## File handling
- [ ] Keep upload root outside the public web root and deny direct web access.
- [ ] Validate file extension, size, actual content signature, and parser behavior.
- [ ] Add malware scanning and safe handling for archive/document bombs.
- [ ] Generate opaque storage names and avoid trusting client filenames.
- [ ] Add per-user quotas, rate limits, and cleanup for abandoned uploads.
- [ ] Test path traversal, symlinks, malformed uploads, and oversized bodies.
- [ ] Set safe download headers and avoid inline rendering of active content.

## Secrets, transport, and deployment
- [ ] Keep `.env`, database credentials, keys, and private uploads out of Git.
- [ ] Rotate any credentials accidentally committed or exposed.
- [ ] Use HTTPS, secure cookies, HSTS, correct trusted origins, and restrictive hosts.
- [ ] Use a production secret manager and `DEBUG=False`.
- [ ] Restrict database network access and require TLS where supported.
- [ ] Configure backups, encryption at rest, recovery tests, and retention.
- [ ] Review dependencies and pin/test updates.

## Audit and monitoring
- [ ] Record upload, download, denial, share, revoke, delete, and admin actions.
- [ ] Avoid recording passwords, tokens, or document contents in logs.
- [ ] Protect audit logs from unauthorized modification and deletion.
- [ ] Add alerting for repeated denied access and suspicious download volume.

## Verification
- [ ] Run `python manage.py test` and record results.
- [ ] Run `python manage.py check --deploy`.
- [ ] Add automated authorization matrix tests for all roles and endpoints.
- [ ] Add upload validation and storage isolation tests.
- [ ] Perform dependency, configuration, and manual penetration review.
- [ ] Confirm no private file path is exposed through a public URL.

## Initial design risks
- Registration supports Document Owner and Viewer only; admin assignment must be a trusted operator action.
- Permission sharing/revocation UI is not yet implemented.
- Extension validation alone is insufficient for hostile files.
- Audit events currently use the same application database; stronger append-only protections may be needed.
- Local private storage is not a substitute for encrypted, access-controlled, durable production object storage.
