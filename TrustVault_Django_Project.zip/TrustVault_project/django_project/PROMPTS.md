# Prompt and work log

## User prompt — 2026-10-21
> We are building TrustVault, a secure document-sharing platform for a security-focused hackathon.
>
> Our stack:
> - Python and Django
> - PostgreSQL
> - Bootstrap
> - GitHub
>
> First, inspect the existing repository and README.
> Do not overwrite existing files without checking them.
>
> Create the initial Django project structure with these apps:
> 1. accounts
> 2. documents
> 3. audit
>
> Requirements:
> - Use Django's built-in authentication.
> - Plan three roles: Administrator, Document Owner and Viewer.
> - Use environment variables for secrets and configuration.
> - Keep uploaded documents in private storage outside the public web directory.
> - Do not expose document files through public URLs.
> - Prepare a PostgreSQL database configuration.
> - Create a .gitignore that excludes .env, virtual environments, private uploads, credentials and generated files.
> - Create THREATS.md with an initial security threat checklist.
> - Create PROMPTS.md with today's actual prompt and the work performed.
> - Update README.md with project setup instructions.
>
> Before making changes, show me the proposed file structure.
> After implementation, explain how to run the project and list any steps that still require manual configuration.
>
> Do not claim security is complete until automated tests verify it. create a project containing home page,login page,registration page and working dashboards and navigation to all pages and make a zip file and netlify link application

## Work performed for this archive
- Inspected the supplied ZIP inventory. It contained an existing `app/` implementation, tests, threat notes, and a `netlify_deploy/` static frontend, but no top-level README was present in the listed files.
- Preserved useful existing project files under `existing_project/` instead of overwriting them.
- Excluded `.git` internals, a local database, bytecode caches, and the bundled `cloudflared.exe` executable from the deliverable archive.
- Created a separate Django starter under `django_project/` with `accounts`, `documents`, and `audit` apps; home, login, registration, dashboard, document and audit pages; environment-based settings; PostgreSQL support; private upload configuration; starter tests; `.gitignore`; `THREATS.md`; and setup documentation.
- Added a Bootstrap-based UI and navigation links between available pages.
- Security is not complete or certified. Run the test suite and complete the threat checklist before real sensitive data or production deployment.
