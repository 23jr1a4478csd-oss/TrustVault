from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse
from accounts.models import Profile
from .models import AuditEvent

class AuditAccessTests(TestCase):
    def test_audit_log_requires_administrator(self):
        viewer = User.objects.create_user(username="viewer", password="Strong-Test-Pass-123!")
        viewer.profile.role = Profile.Role.VIEWER
        viewer.profile.save()
        self.client.login(username="viewer", password="Strong-Test-Pass-123!")
        self.assertEqual(self.client.get(reverse("audit:list")).status_code, 403)
    def test_admin_can_view_audit_log(self):
        admin = User.objects.create_user(username="admin", password="Strong-Test-Pass-123!", is_staff=True)
        self.client.login(username="admin", password="Strong-Test-Pass-123!")
        self.assertEqual(self.client.get(reverse("audit:list")).status_code, 200)
