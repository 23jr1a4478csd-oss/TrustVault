from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render
from .models import AuditEvent

@login_required
@user_passes_test(lambda u: u.is_staff or (getattr(getattr(u, "profile", None), "role", "") == "administrator"))
def event_list(request):
    events = AuditEvent.objects.select_related("actor", "document")[:200]
    return render(request, "audit/events.html", {"events": events})
