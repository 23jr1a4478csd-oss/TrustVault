from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render
from django.views.decorators.http import require_http_methods
from documents.models import Document
from .forms import RegistrationForm

def register(request):
    if request.user.is_authenticated:
        return redirect("accounts:dashboard")
    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, "Welcome to TrustVault.")
        return redirect("accounts:dashboard")
    return render(request, "accounts/register.html", {"form": form})

@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.user.is_authenticated:
        return redirect("accounts:dashboard")
    form = AuthenticationForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect("accounts:dashboard")
    return render(request, "accounts/login.html", {"form": form})

@login_required
def dashboard(request):
    profile = getattr(request.user, "profile", None)
    role = profile.role if profile else "viewer"
    if request.user.is_staff or role == "administrator":
        docs = Document.objects.all().order_by("-created_at")[:10]
        title = "Administrator Dashboard"
    elif role == "owner":
        docs = Document.objects.filter(owner=request.user).order_by("-created_at")
        title = "Document Owner Dashboard"
    else:
        docs = Document.objects.filter(permissions__user=request.user, permissions__can_view=True).distinct().order_by("-created_at")
        title = "Viewer Dashboard"
    return render(request, "accounts/dashboard.html", {"documents": docs, "dashboard_title": title, "role": role})
