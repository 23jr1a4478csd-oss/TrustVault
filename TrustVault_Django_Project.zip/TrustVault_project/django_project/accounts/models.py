from django.conf import settings
from django.db import models

class Profile(models.Model):
    class Role(models.TextChoices):
        ADMINISTRATOR = "administrator", "Administrator"
        OWNER = "owner", "Document Owner"
        VIEWER = "viewer", "Viewer"
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.VIEWER)
    def __str__(self):
        return f"{self.user.username} ({self.get_role_display()})"
