from django.test import TestCase
from django.urls import reverse

class AuthPageTests(TestCase):
    def test_home_page_loads(self):
        self.assertEqual(self.client.get(reverse("home")).status_code, 200)
    def test_login_and_registration_pages_load(self):
        self.assertEqual(self.client.get(reverse("accounts:login")).status_code, 200)
        self.assertEqual(self.client.get(reverse("accounts:register")).status_code, 200)
    def test_dashboard_requires_login(self):
        response = self.client.get(reverse("accounts:dashboard"))
        self.assertEqual(response.status_code, 302)
