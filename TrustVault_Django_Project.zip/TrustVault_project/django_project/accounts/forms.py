from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile

class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    role = forms.ChoiceField(choices=[(Profile.Role.OWNER, "Document Owner"), (Profile.Role.VIEWER, "Viewer")])
    class Meta:
        model = User
        fields = ("username", "email", "role", "password1", "password2")
    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            user.email = self.cleaned_data["email"]
            user.save(update_fields=["email"])
            user.profile.role = self.cleaned_data["role"]
            user.profile.save(update_fields=["role"])
        return user
